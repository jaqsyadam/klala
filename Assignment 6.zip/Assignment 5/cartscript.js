document.addEventListener('DOMContentLoaded', () => {
    updateCart();
});

document.querySelectorAll('input[name="paymentMethod"]').forEach((elem) => {
    elem.addEventListener("change", function(event) {
        var creditCardForm = document.getElementById("creditCardForm");
        if (event.target.value === "creditCard") {
            creditCardForm.style.display = "block";
        } else {
            creditCardForm.style.display = "none";
        }
    });
});

document.getElementById('checkoutButton').addEventListener('click', function() {
    var selectedPaymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
    if (selectedPaymentMethod === "creditCard") {
        // Validate credit card details here
        var cardNumber = document.getElementById('cardNumber').value;
        var expiryDate = document.getElementById('expiryDate').value;
        var cvv = document.getElementById('cvv').value;
        if (cardNumber && expiryDate && cvv) {
            alert('Payment processed successfully!');
            // Here you would typically send the payment details to your server
        } else {
            alert('Please fill in all credit card details.');
        }
    } else {
        // Redirect to PayPal
        alert('Redirecting to PayPal...');
    }
});

// Theme toggle
document.getElementById('themeToggle').addEventListener('click', function() {
    document.body.classList.toggle('night-theme');
    const icon = this.querySelector('i');
    if (document.body.classList.contains('night-theme')) {
        icon.classList.replace('bi-sun', 'bi-moon');
    } else {
        icon.classList.replace('bi-moon', 'bi-sun');
    }
});