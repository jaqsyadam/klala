const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const toggleToRegister = document.getElementById('toggleToRegister');
const toggleToLogin = document.getElementById('toggleToLogin');
const formTitle = document.getElementById('formTitle');

// Redirect function to main shop page
function redirectToShop() {
    window.location.href = 'home.html';
}

// Validate email format
function validateEmail(email) {
    const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return re.test(email);
}

// Handle login form submission
loginForm.addEventListener('submit', function(event) {
    event.preventDefault();

    document.getElementById('loginEmailOrPhoneError').style.display = 'none';
    document.getElementById('loginPasswordError').style.display = 'none';

    const emailOrPhone = document.getElementById('loginEmailOrPhone').value;
    const password = document.getElementById('loginPassword').value;
    let isValid = true;

    if (!validateEmail(emailOrPhone) && !/^\d+$/.test(emailOrPhone)) {
        document.getElementById('loginEmailOrPhoneError').textContent = 'Invalid email format or phone number';
        document.getElementById('loginEmailOrPhoneError').style.display = 'block';
        isValid = false;
    }

    if (password.length < 6) {
        document.getElementById('loginPasswordError').textContent = 'Password must be at least 6 characters long';
        document.getElementById('loginPasswordError').style.display = 'block';
        isValid = false;
    }

    if (isValid) {
        localStorage.setItem('LoginMessage', 'Logged into your account successfully');
        redirectToShop();
    }
});


// Handle register form submission
registerForm.addEventListener('submit', function(event) {
    event.preventDefault();

    document.getElementById('registerNameError').style.display = 'none';
    document.getElementById('registerPhoneError').style.display = 'none';
    document.getElementById('registerEmailError').style.display = 'none';
    document.getElementById('registerPasswordError').style.display = 'none';
    document.getElementById('confirmPasswordError').style.display = 'none';

    let isValid = true;

    if (name.trim() === '') {
        document.getElementById('registerNameError').textContent = 'Name is required';
        document.getElementById('registerNameError').style.display = 'block';
        isValid = false;
    }

    if (!/^\d+$/.test(phone)) {
        document.getElementById('registerPhoneError').textContent = 'Phone number must be numeric';
        document.getElementById('registerPhoneError').style.display = 'block';
        isValid = false;
    }

    if (!validateEmail(email)) {
        document.getElementById('registerEmailError').textContent = 'Invalid email format';
        document.getElementById('registerEmailError').style.display = 'block';
        isValid = false;
    }

    if (password.length < 6) {
        document.getElementById('registerPasswordError').textContent = 'Password must be at least 6 characters long';
        document.getElementById('registerPasswordError').style.display = 'block';
        isValid = false;
    } else if (password !== confirmPassword) {
        document.getElementById('confirmPasswordError').textContent = 'Passwords do not match';
        document.getElementById('confirmPasswordError').style.display = 'block';
        isValid = false;
    }

    if (isValid) {
        localStorage.setItem('notification', 'Registration successfully!');
        redirectToShop();
    }
});

 toggleToRegister.addEventListener('click', function() {
    loginForm.style.display = 'none';
    registerForm.style.display = 'block';
    formTitle.textContent = 'Register';
});

toggleToLogin.addEventListener('click', function() {
    registerForm.style.display = 'none';
    loginForm.style.display = 'block';
    formTitle.textContent = 'Login';
});